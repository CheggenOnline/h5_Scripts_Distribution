/**
 * H5 Script SDK sample.
 */
/**
 * Shows a message dialog information about the connected element and script arguments.
 */
var H5SampleHelloWorld = /** @class */ (function () {
    function H5SampleHelloWorld() {
    }
    /**
     * Script initialization function.
     */
    H5SampleHelloWorld.Init = function (args) {
        alert("Hello world");
    };
    return H5SampleHelloWorld;
}());
//# sourceMappingURL=H5SampleHelloWorld.js.map