/// <reference path="jquery.d.ts"/>

interface JQueryStatic {
	toJSON(s: any): string;
}