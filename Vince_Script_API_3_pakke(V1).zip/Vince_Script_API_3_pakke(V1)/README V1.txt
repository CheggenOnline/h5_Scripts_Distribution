Content in this package:
* Vince_Modal (V1.4)
* Vince_Script_API_3 (V1.0)
* Code-folder: This contains the typescript files for the two scripts, in case anyone wants to have a look

Install:
* Go to: M3 > H5 Administration Tools > H5 Administration > Data files
* "Change file type" => H5 Script
* Click "Import Zip"
* Select the zipfile "UPLOAD ME"
* Click "OK" when asked if you want to import the file
* IF Zip upload fails, unpack the folder and upload the 2 files separately using the "upload" button


Usage:
* add the script as a shortcut in the program where you want to use it
* OBS! If you want to use the script multiple times in the same panel, Make sure to give each instance of the script a unique argument in that panel (for instance a number)



